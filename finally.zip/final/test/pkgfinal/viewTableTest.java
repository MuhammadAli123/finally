/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;


public class viewTableTest {
    
    public viewTableTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    
    @Test
    public void testUpdate_table() {
        System.out.println("Update_table");
        viewTable instance = new viewTable();
        instance.Update_table();
       
    }

   
    @Test
    public void testClose() {
        System.out.println("close");
        viewTable instance = new viewTable();
        instance.close();
        
    }

    
    @Test
    public void testIcon() {
        System.out.println("icon");
        viewTable instance = new viewTable();
        instance.icon();
        
    }

    
    @Test
    public void testCurrentDate() {
        System.out.println("currentDate");
        viewTable instance = new viewTable();
        instance.currentDate();
        
    }

    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        viewTable.main(args);
       
    }

    
    @Test
    public void testSale_Update_table() {
        System.out.println("Sale_Update_table");
        viewTable instance = new viewTable();
        instance.Sale_Update_table();
       
        fail("The test case is a prototype.");
    }
    
}
