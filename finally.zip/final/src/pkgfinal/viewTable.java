package pkgfinal;


import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;

//import java.awt.Image;
import java.io.FileOutputStream;
import static java.lang.String.valueOf;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
//import javax.swing.text.Document;
import net.proteanit.sql.DbUtils;
import java.awt.event.*;
import java.awt.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import static javax.swing.UIManager.getString;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ali
 */
public class viewTable extends javax.swing.JFrame {

    Connection conn = null;
        ResultSet rs = null;
        PreparedStatement pst = null;
    
    public viewTable() {
        initComponents();
        
       conn = conn2.DB();
       combobox();
       icon();
       currentDate();
       
       Sale_Record();
    }
 
   createTable ct =new   createTable();
   
 public void Update_table(){        /*update_table_sale*/

        try{
       
    String sql ="select * from  '"+jComboBox1.getSelectedItem()+"' order by ID";
    pst = conn.prepareStatement(sql);
    rs = pst.executeQuery();
    purchaseTable.setModel(DbUtils.resultSetToTableModel(rs));
      }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }
        }
 
 //Sale update table
  public void Sale_Update_table(){        /*sale_update_table_sale*/

        try{
       
    String sql ="select * from  '"+jComboBox1.getSelectedItem()+"_sale"+"' order by ID";
    pst = conn.prepareStatement(sql);
    rs = pst.executeQuery();
    SaleTable.setModel(DbUtils.resultSetToTableModel(rs));
      }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }
        }
 
        
              
                 /// My cor for Sale record
      private void Sale_Record(){
   
       try{      
      
          String sql5 ="SELECT name FROM sqlite_master where type='table'";
            pst = conn.prepareStatement(sql5);
            rs = pst.executeQuery();
         
           TableModel tableModel = recordT.getModel(); 
           
            java.util.List tableNames = DbUtils.resultSetToNestedList(rs);    
           
            int rowIndex = 0;
                    
            for (Object tableName : tableNames) {
                String strTableName = tableName.toString().replace("[", "").replace("]", "");
                   /// for final
                try {
                   String sql6 ="SELECT PBrandName , sum(PurchaseQuantity)from '"+strTableName+"'";
                   pst = conn.prepareStatement(sql6);               
                   rs = pst.executeQuery();
                    
                   // System.out.print("Table Name: " + strTableName);
                   // System.out.println("Columns " + rs.getMetaData().getColumnCount());               
                    while (rs.next()) {                    
                        try {
                            String BrandName = rs.getString(1);
                            recordT.setValueAt(BrandName, rowIndex, 0);
                          
                            double Pursum  = rs.getDouble(2);
                            recordT.setValueAt(Pursum, rowIndex, 1);
                          
                           
                           // rowIndex++;
                            
                        } catch (Exception e) {
                        }
                            
                    }                    
                } catch (Exception e) {
                }
                 finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }
                int rowIndexsale =0;
                // for final_sale
                try {
                   String sql6 ="SELECT  SBrandName, sum(SaleQuantity) from '"+strTableName+"'";
                   pst = conn.prepareStatement(sql6);               
                   rs = pst.executeQuery();
                    
               //   System.out.println("Columns " + rs.getMetaData().getColumnCount());               
                    while (rs.next()) {                    
                        try {
                            String BrandName = rs.getString(1);
                            recordT.setValueAt(BrandName, rowIndex, 0);
                            double salesum = rs.getDouble(2);
                            recordT.setValueAt(salesum, rowIndex, 2);
 
                          rowIndex++;
                            
                        } catch (Exception e) {
                        }
                         
                      }                    
                } catch (Exception e) {
                   
                }
                finally{
                    try{
                    rs.close();
                    pst.close();
                   }
                    catch(Exception e){
                    }
                   }
              recordT.setModel(tableModel);
         
                }
       
        }
         
       catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
       }
     
                
           // working for purchase - sale 
      int row;
       int coulom = 0;
        int rowLength=recordT.getRowCount();      
             for( row=0; row<rowLength; row++){
          // System.out.println("count"+row);
         double pur =   (double) recordT.getValueAt( row,1);   //1,1
         double sal =(double)    recordT.getValueAt( row,2);     // 1,2
           
              double total = pur - sal;
              recordT.setValueAt(total, row,3);
              } // end of row loop
           // row++; 
             rowLength++;
       
   }
   
    private void combobox(){
    
            try{
            String sql4 ="SELECT name FROM sqlite_master WHERE type='table'";
            pst = conn.prepareStatement(sql4);
            rs = pst.executeQuery(); 
     
               while(rs.next()){
                   
                   jComboBox1.addItem(rs.getString(1)); 
                   PurCom.addItem(rs.getString(1));
                   SalCom.addItem(rs.getString(1));
                   
                }  
              }
                catch(Exception e){
                 JOptionPane.showMessageDialog(null, "combox method line no 311");
                 }
                  finally{
     
                   try{
                    rs.close();
                    pst.close();
                      }
                  catch(Exception e){
                    }
                   }
    }
    
     public void close(){
     
      WindowEvent ClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
      Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(ClosingEvent);
     }
  
     public void icon(){
     
       JFrame frame = new JFrame();
       setTitle("Bussines Manager 1.0");
       setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("CIcon.jpg")));
     }
    
     public void currentDate(){
     
       Thread clock  = new Thread(){
       
         public void run(){
         
           for(;;){
              
               try{
                 Calendar cal = new GregorianCalendar();
                 int day = cal.get(Calendar.DAY_OF_MONTH);
                 int month = cal.get(Calendar.MONTH);
                 int year = cal.get(Calendar.YEAR);
                 Date.setText(" Date: "+day+"/"+(month+1)+"/"+year+" ");
                 
                 int sec = cal.get(Calendar.SECOND);
                 int min = cal.get(Calendar.MINUTE);
                 int hour = cal.get(Calendar.HOUR);
               //  int amPm = 9;
             //    int amPm = cal.get(Calendar.AM_PM);
                 time_txt.setText("Time: "+hour+":"+min+":"+sec+" ");
                 sleep(1000);
               }
              catch(InterruptedException ex){
                Logger.getLogger(viewTable.class.getName()).log(Level.SEVERE, null, ex);
              } 
           }  
         }
      };
       clock.start();
     }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox();
        jPanel7 = new javax.swing.JPanel();
        TotalQuantity = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        T_pur = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        T_sale = new javax.swing.JTextField();
        T_Quantity = new javax.swing.JTextField();
        Print = new javax.swing.JButton();
        SaveReport = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        search_tf = new javax.swing.JTextField();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel9 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        ShowPurchaseName = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        purchaseTable = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        sno = new javax.swing.JTextField();
        Purdate = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        PurCom = new javax.swing.JComboBox();
        PurchaseManufacture = new javax.swing.JTextField();
        purchase_Quantiy = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        Purchase_Add_sub = new javax.swing.JTextField();
        Purchase_ADD_Btn = new javax.swing.JButton();
        Purchase_SUB_Btn = new javax.swing.JButton();
        InsertDataPurchase = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        SaleTable = new javax.swing.JTable();
        ShowSaleName = new javax.swing.JLabel();
        jButton20 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        snoS = new javax.swing.JTextField();
        dateS = new com.toedter.calendar.JDateChooser();
        SaleManufactureTextfield = new javax.swing.JTextField();
        Sale_Quantity = new javax.swing.JTextField();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        SalCom = new javax.swing.JComboBox();
        jPanel17 = new javax.swing.JPanel();
        Sale_Add_sub = new javax.swing.JTextField();
        Sale_ADD_Btn = new javax.swing.JButton();
        Sale_SUB_Btn = new javax.swing.JButton();
        InsertDataSale = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        recordT = new javax.swing.JTable();
        jButton10 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jToolBar1 = new javax.swing.JToolBar();
        Date = new javax.swing.JLabel();
        time_txt = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        searchSale_tf1 = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        Date_txt = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 750));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Table" }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jComboBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox1MouseClicked(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Total Quantity", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 14), new java.awt.Color(255, 51, 102))); // NOI18N

        TotalQuantity.setText("Total Quantities");
        TotalQuantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalQuantityActionPerformed(evt);
            }
        });

        jLabel11.setText("Total Sale");

        jLabel10.setText("Total Purchase");

        jLabel12.setText("Total Quantity");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(TotalQuantity))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(T_pur, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(T_sale, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(T_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(T_pur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_sale, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TotalQuantity)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        Print.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/PRI.PNG"))); // NOI18N
        Print.setText("Print");
        Print.setPreferredSize(new java.awt.Dimension(80, 30));
        Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintActionPerformed(evt);
            }
        });

        SaveReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/save.png"))); // NOI18N
        SaveReport.setText("save Report");
        SaveReport.setPreferredSize(new java.awt.Dimension(111, 30));
        SaveReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveReportActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(204, 204, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase Search", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 102, 255))); // NOI18N

        search_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_tfKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_tf, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/de.PNG"))); // NOI18N
        jButton13.setText("Delete Purchase");
        jButton13.setToolTipText("delete item");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        ShowPurchaseName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ShowPurchaseName.setForeground(new java.awt.Color(204, 0, 0));
        ShowPurchaseName.setText("Show Purchase Name");

        purchaseTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        purchaseTable.setForeground(new java.awt.Color(0, 0, 255));
        purchaseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        purchaseTable.setRowHeight(30);
        purchaseTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                purchaseTableMouseClicked(evt);
            }
        });
        purchaseTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                purchaseTableKeyReleased(evt);
            }
        });
        jScrollPane4.setViewportView(purchaseTable);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(ShowPurchaseName, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                .addComponent(jButton13)
                .addGap(80, 80, 80))
            .addComponent(jScrollPane4)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ShowPurchaseName, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Purchase Record", jPanel9);

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase Input", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(210, 62, 210))); // NOI18N

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Serial no");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setText("Date");

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setText("Brand Name");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setText("Manufacture Name");

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel17.setText("purchase Quantity");

        PurCom.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item" }));
        PurCom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurComActionPerformed(evt);
            }
        });

        PurchaseManufacture.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PurchaseManufactureActionPerformed(evt);
            }
        });

        purchase_Quantiy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchase_QuantiyActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/save.png"))); // NOI18N
        jButton2.setText("Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/up.PNG"))); // NOI18N
        jButton14.setText("Update");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setText("Clear");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jPanel18.setBackground(new java.awt.Color(255, 204, 204));
        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase_Update/Return", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 0, 12), new java.awt.Color(255, 51, 51))); // NOI18N

        Purchase_ADD_Btn.setText("Add");
        Purchase_ADD_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Purchase_ADD_BtnActionPerformed(evt);
            }
        });

        Purchase_SUB_Btn.setText("Sub");
        Purchase_SUB_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Purchase_SUB_BtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Purchase_Add_sub, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(Purchase_ADD_Btn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Purchase_SUB_Btn)
                        .addGap(8, 8, 8)))
                .addGap(25, 25, 25))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Purchase_Add_sub, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Purchase_ADD_Btn)
                    .addComponent(Purchase_SUB_Btn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jButton15))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jLabel17))
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel13)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel16))))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PurCom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Purdate, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                            .addComponent(PurchaseManufacture)
                            .addComponent(purchase_Quantiy)
                            .addComponent(sno))))
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton14)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addComponent(sno, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Purdate, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel14)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PurCom, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PurchaseManufacture, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)))
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(purchase_Quantiy, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton14)
                    .addComponent(jButton15))
                .addGap(33, 33, 33))
        );

        InsertDataPurchase.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        InsertDataPurchase.setForeground(new java.awt.Color(110, 128, 208));
        InsertDataPurchase.setText("Insert Data Purchase");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(InsertDataPurchase, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(73, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(InsertDataPurchase, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Purchase Input", jPanel11);

        SaleTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SaleTable.setForeground(new java.awt.Color(0, 0, 255));
        SaleTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        SaleTable.setRowHeight(30);
        SaleTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SaleTableMouseClicked(evt);
            }
        });
        SaleTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                SaleTableKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(SaleTable);

        ShowSaleName.setBackground(new java.awt.Color(255, 0, 51));
        ShowSaleName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ShowSaleName.setForeground(new java.awt.Color(204, 0, 0));
        ShowSaleName.setText("Show Sale Name");

        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/de.PNG"))); // NOI18N
        jButton20.setText("Delete Sale");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 797, Short.MAX_VALUE)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(ShowSaleName, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton20)
                .addGap(124, 124, 124))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton20)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(ShowSaleName, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Sale Record", jPanel16);

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale Input", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(210, 62, 210))); // NOI18N

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel18.setText("Serial no");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel21.setText("Date");

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel22.setText("Brand Name");

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel23.setText("Manufacture Name");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel24.setText("Sale Quantity");

        jButton16.setText("Clear");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/save.png"))); // NOI18N
        jButton17.setText("Save");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/up.PNG"))); // NOI18N
        jButton18.setText("Update");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        SalCom.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item" }));
        SalCom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalComActionPerformed(evt);
            }
        });

        jPanel17.setBackground(new java.awt.Color(255, 204, 204));
        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale_Add / Return", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 0, 12), new java.awt.Color(255, 51, 51))); // NOI18N

        Sale_ADD_Btn.setText("Add");
        Sale_ADD_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sale_ADD_BtnActionPerformed(evt);
            }
        });

        Sale_SUB_Btn.setText("Sub");
        Sale_SUB_Btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sale_SUB_BtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Sale_Add_sub)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(Sale_ADD_Btn)
                        .addGap(18, 18, 18)
                        .addComponent(Sale_SUB_Btn)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(Sale_Add_sub, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Sale_SUB_Btn)
                    .addComponent(Sale_ADD_Btn))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22))
                                .addGap(28, 28, 28)))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addGap(19, 19, 19)
                                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(snoS)
                                        .addComponent(dateS, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                                        .addComponent(Sale_Quantity)))
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addComponent(SalCom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(SaleManufactureTextfield, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(113, 113, 113)
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(49, Short.MAX_VALUE))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jButton16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton18)
                        .addGap(84, 84, 84))))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(snoS, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateS, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SalCom, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SaleManufactureTextfield, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23)))
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(Sale_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jButton16)
                        .addContainerGap(46, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton18)
                            .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(59, 59, 59))))
        );

        InsertDataSale.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        InsertDataSale.setForeground(new java.awt.Color(110, 128, 208));
        InsertDataSale.setText("Insert Data Sale");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(118, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(InsertDataSale, javax.swing.GroupLayout.PREFERRED_SIZE, 564, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(InsertDataSale, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab(" Sale Input", jPanel12);

        recordT.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        recordT.setForeground(new java.awt.Color(0, 0, 255));
        recordT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {"",  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null},
                {null,  new Double(0.0),  new Double(0.0), null}
            },
            new String [] {
                "BrandName", "purchaseQuantity", "saleQuantity", "TotalQuantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        recordT.setRowHeight(30);
        recordT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recordTMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(recordT);

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/PRI.PNG"))); // NOI18N
        jButton10.setText("Print Stock Report");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 797, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton10)
                .addGap(153, 153, 153))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(jButton10)
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("Stock Reprt", jPanel13);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkgfinal/res.PNG"))); // NOI18N
        jButton1.setToolTipText("Go Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jToolBar1.setRollover(true);

        Date.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Date.setText("Date");
        jToolBar1.add(Date);

        time_txt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        time_txt.setText("Time");
        jToolBar1.add(time_txt);

        jPanel19.setBackground(new java.awt.Color(204, 204, 255));
        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale Search", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 102, 255))); // NOI18N

        searchSale_tf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchSale_tf1KeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchSale_tf1, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchSale_tf1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Date_txt.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("New");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        Date_txt.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Close");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        Date_txt.add(jMenuItem2);

        jMenuBar1.add(Date_txt);

        jMenu2.setText("Edit");

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Clear");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 802, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(Print, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SaveReport, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(36, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(117, 117, 117))))
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(629, Short.MAX_VALUE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(338, 338, 338)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Print, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SaveReport, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(248, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(30, 30, 30)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(570, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox1PopupMenuWillBecomeInvisible
    
    }//GEN-LAST:event_jComboBox1PopupMenuWillBecomeInvisible

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
    
         try{
            
    String sql =" select * from  '"+jComboBox1.getSelectedItem()+"' ";  
    pst = conn.prepareStatement(sql);
    rs = pst.executeQuery();
    purchaseTable.setModel(DbUtils.resultSetToTableModel(rs));
    ShowPurchaseName.setText("right now you are watching "+jComboBox1.getSelectedItem().toString()+" Record");   
    
    String SaleTabl =" select * from  '"+jComboBox1.getSelectedItem()+"_sale"+"'   ";   /*"_sale"*/
    pst = conn.prepareStatement(SaleTabl);
    rs = pst.executeQuery();
    SaleTable.setModel(DbUtils.resultSetToTableModel(rs));
    ShowSaleName.setText("right now you are watching "+jComboBox1.getSelectedItem()+"_Sale".toString()+" Record");   
        
     
            }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }

            
            
       /*     try{
               String sql = "select sum(PurchaseQuantity), sum(SaleQuantity), sum(TotalQuantity) from '"+jComboBox1.getSelectedItem()+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            recordT.setModel(DbUtils.resultSetToTableModel(rs));
            
                 if(rs.next()){
                     //     for(int a =1; a<=sql.length(); a++){

                String sum1 = rs.getString("sum(PurchaseQuantity)");
             //    recordT.addItem(sum1);
               
                String sum2= rs.getString("sum(SaleQuantity)");
            //    T_sale.setText(sum2);
                
                String sum3 = rs.getString("sum(TotalQuantity)");
            //    T_Quantity.setText(sum3);
            }
            }
            catch(Exception e){}    */
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        options op = new options();
        op.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseClicked
       
     
    }//GEN-LAST:event_jComboBox1MouseClicked

    private void PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintActionPerformed
       
         MessageFormat header = new MessageFormat(" '"+jComboBox1.getSelectedItem()+"' Report");
          MessageFormat sale = new MessageFormat(" '"+jComboBox1.getSelectedItem()+"_sale"+"' Report");
        MessageFormat footer = new MessageFormat("Page{0,number,integer}");
        
        try{
          purchaseTable.print(JTable.PrintMode.NORMAL, header, footer);
          purchaseTable.print(JTable.PrintMode.NORMAL, sale, footer);
        }
        catch(java.awt.print.PrinterException e){
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }//GEN-LAST:event_PrintActionPerformed

    private void SaveReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveReportActionPerformed
        
          try{
       Document document = new Document();
        
       PdfWriter.getInstance(document,new FileOutputStream(" "+jComboBox1.getSelectedItem()+".pdf"));
        document.open();
     //   Image image =  Image.getInstance("save.png");
   //     document.add(new Paragraph("image"));
    //    document.add(image);
        document.add(new Paragraph("ECHO TRADERS",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.RED)));
        document.add(new Paragraph(" "+jComboBox1.getSelectedItem()+ "  Report ",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.BLUE)));
        document.add(new Paragraph(new java.util.Date().toString())) ;
        document.add(new Paragraph("--------------------------------------------------------"));
        PdfPTable table = new PdfPTable(5);
        PdfPCell cell= new PdfPCell (new Paragraph("Purcahse Report"));
        PdfPCell cell1= new PdfPCell (new Paragraph("ID      |   Date     |    ManufacName     |    BrandName     |    PurQt  "));
        
        cell.setColspan(5);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBackgroundColor(BaseColor.GREEN);
        table.addCell(cell);
        
        cell1.setColspan(5);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setBackgroundColor(BaseColor.PINK);
        table.addCell(cell1);
        
        
        String sql = "select * from '"+jComboBox1.getSelectedItem()+"' ";
               pst = conn.prepareStatement(sql);
               rs=pst.executeQuery();
      while(rs.next()){
                       
                        String v1 = rs.getString("ID");
                        String add = rs.getString("purDate");          
                        String v2 = rs.getString("PBrandName");
                        String v3 = rs.getString("PManufactureName");
                        String v4 = rs.getString("PurchaseQuantity");
                     /*   String v5 =rs.getString("SaleQuantity");
                        String v6 =rs.getString("TotalQuantity");*/

                  
                        table.addCell(v1);
               //       table.addCell(v/*.date_tf.getDateFormatString()*/);
                        table.addCell(add);
                        table.addCell(v3);
                        table.addCell(v2);
                        table.addCell(v4);
                
                   
                       
         }
       document.add(table);
      // working for sum(PurchaseQuantity)
                 
                   String SumPurchaseQuantityPDF ="SELECT  PBrandName, sum(PurchaseQuantity) from '"+jComboBox1.getSelectedItem()+"'";
                   pst = conn.prepareStatement(SumPurchaseQuantityPDF);               
                   rs = pst.executeQuery();
                   while(rs.next()){
                  String purchaseQuantity = rs.getString("sum(PurchaseQuantity)");
                   //    System.out.println("total Purchase"+purchaseQuantity);
                      com.itextpdf.text.List listpurchase = new com.itextpdf.text.List(20);
                      listpurchase.add("Total Purchase: "+purchaseQuantity);
                       document.add(listpurchase);
                   }
                    
         com.itextpdf.text.List list = new com.itextpdf.text.List(true,20);
         list.add("Printed Date:_____________");
         list.add("Signature:_______________");
         document.add(list);
                   
         document.add(new Paragraph("--------------------------------------------------------------------------------------"));
         document.add(new Paragraph("\r\r\r Circle (A Software Company)",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.add(new Paragraph(" Contact: 03232548099",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.add(new Paragraph(" Email: circleshouse@gmail.com",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.close();
      
        }
        catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        }
          
          // save report for SALE
           
          try{
       Document document = new Document();
        
       PdfWriter.getInstance(document,new FileOutputStream(" "+jComboBox1.getSelectedItem()+"_sale"+".pdf"));
        document.open();
     //   Image image =  Image.getInstance("save.png");
   //     document.add(new Paragraph("image"));
    //    document.add(image);
        document.add(new Paragraph("ECHO TRADERS",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.RED)));
        document.add(new Paragraph(" "+jComboBox1.getSelectedItem()+ "  Report ",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.BLUE)));
        document.add(new Paragraph(new java.util.Date().toString())) ;
        document.add(new Paragraph("--------------------------------------------------------"));
        PdfPTable table = new PdfPTable(5);
        PdfPCell cell= new PdfPCell (new Paragraph("Sale Report"));
        PdfPCell cell1= new PdfPCell (new Paragraph("ID      |   Date     |    ManufacName     |    BrandName     |    PurQt  "));
        
        cell.setColspan(5);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBackgroundColor(BaseColor.GREEN);
        table.addCell(cell);
        
        cell1.setColspan(5);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setBackgroundColor(BaseColor.PINK);
        table.addCell(cell1);
        
        
        String sql = "select * from '"+jComboBox1.getSelectedItem()+"_sale"+"' ";
             pst = conn.prepareStatement(sql);
          rs=pst.executeQuery();
      while(rs.next()){
                       
                        String v1 = rs.getString("ID");
                        String add = rs.getString("saleDate");          
                        String v2 = rs.getString("SBrandName");
                        String v3 = rs.getString("SManufactureName");
                        String v4 =rs.getString("SaleQuantity");
                       
                    table.addCell(v1);
                    table.addCell(add);
                    table.addCell(v3);
                    table.addCell(v2);
                    table.addCell(v4);
                }
        document.add(table);
        
          String SumSaleQuantityPDF ="SELECT  SBrandName, sum(SaleQuantity) from '"+jComboBox1.getSelectedItem()+"_sale"+"'";
                   pst = conn.prepareStatement(SumSaleQuantityPDF);               
                   rs = pst.executeQuery();
                   while(rs.next()){
                      String SaleQuantity = rs.getString("sum(SaleQuantity)");
                   //   System.out.println("total Purchase"+SaleQuantity);
                      com.itextpdf.text.List listSale = new com.itextpdf.text.List(20);
                      listSale.add("Total Purchase: "+SaleQuantity);
                      document.add(listSale);
                   }

         com.itextpdf.text.List list = new com.itextpdf.text.List(true,20);
         list.add("Printed Date:_____________");
         list.add("Signature:_______________");
         document.add(list);
        
         document.add(new Paragraph("--------------------------------------------------------------------------------------"));
         document.add(new Paragraph("\r\r\r Circle (A Software Company)",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.add(new Paragraph(" Contact: 03232548099",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.add(new Paragraph(" Email: circleshouse@gmail.com",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
         document.close();
        JOptionPane.showMessageDialog(null, "Saved Report");
        }
        catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_SaveReportActionPerformed

    private void TotalQuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalQuantityActionPerformed
        
       try{
           String PurchaseQuantity = "select sum(PurchaseQuantity)  from '"+jComboBox1.getSelectedItem()+"'";
            pst = conn.prepareStatement(PurchaseQuantity);
            rs = pst.executeQuery();
            
           
            if(rs.next()){
            String sum1 = rs.getString("sum(PurchaseQuantity)");
                T_pur.setText(sum1);
                  
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
    }
        
        // for sale
        
        try{
            String saleQuantity = "select sum(SaleQuantity)  from '"+jComboBox1.getSelectedItem()+"_sale"+"'";
            pst = conn.prepareStatement(saleQuantity);
            rs = pst.executeQuery();
            
            if(rs.next()){
                String sum2= rs.getString("sum(SaleQuantity)");
                T_sale.setText(sum2);   
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
    }
        try{
      double sub = Double.parseDouble(T_pur.getText());
            double sub2 = Double.parseDouble(T_sale.getText());
            double v = sub-sub2;
            T_Quantity.setText(String.valueOf(v));  
         
        }
        catch(Exception e){}
    }//GEN-LAST:event_TotalQuantityActionPerformed

    private void search_tfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_tfKeyReleased
        
             try{
            String sql = "Select * from '"+jComboBox1.getSelectedItem()+"' where ID=?";

            pst = conn.prepareStatement(sql);
            pst.setString(1, search_tf.getText());
            rs= pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("ID");
                sno.setText(add1);
                java.util.Date add2 = rs.getDate("PurDate");
                Purdate.setDate(add2);
                String add4 = rs.getString("PManufactureName");
                PurchaseManufacture.setText(add4);
                String add5 = rs.getString("PurchaseQuantity");
                purchase_Quantiy.setText(add5);
                String add3 = rs.getString("PBrandName");
                PurCom.setSelectedItem(add3);
             
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
           Update_table();
    }//GEN-LAST:event_search_tfKeyReleased

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        
        dispose();
        SplashScreen ss = new SplashScreen();
        ss.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        close();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        
     
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
        
        
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    private void recordTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recordTMouseClicked

 
    }//GEN-LAST:event_recordTMouseClicked

    private void SalComActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalComActionPerformed

        try{

            String sql =" select * from  '"+SalCom.getSelectedItem()+"' ";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            purchaseTable.setModel(DbUtils.resultSetToTableModel(rs));
            InsertDataSale.setText("the record will save in " +SalCom.getSelectedItem()+"_sale".toString());

        }
        catch(Exception e){

            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){
            }
        }
    }//GEN-LAST:event_SalComActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed

        try{

            String sns  = snoS.getText();
            String dd   =(((JTextField)dateS.getDateEditor().getUiComponent()).getText());
         //   String scom = SalCom.getSelectedObjects().toString();
          //  SManufactureName='"+bran+"',
            String bran = SaleManufactureTextfield.getText();
            String SaQ  = Sale_Quantity.getText();
                 /*SManufactureName='"+scom+"',*/
            String up = "update '"+SalCom.getSelectedItem()+"_sale"+"' set Id='"+sns+"', SaleDate='"+dd+"',   SManufactureName='"+bran+"', SaleQuantity='"+SaQ+"'   where id='"+sns+"'";
            pst = conn.prepareStatement(up);
            pst.execute();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
        Sale_Update_table();
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed

        try{
            String sal = "insert into '"+SalCom.getSelectedItem()+"_sale"+"'(Saledate, SBrandName, SManufactureName,  SaleQuantity ) values(?,?,?,?)";
            pst= conn.prepareStatement(sal);

            /* pst.setString(1,snoS.getText());*/
            pst.setString(1,((JTextField)dateS.getDateEditor().getUiComponent()).getText());
            pst.setString(2, SalCom.getSelectedItem().toString());
            pst.setString(3, SaleManufactureTextfield.getText());
            pst.setString(4, Sale_Quantity.getText());

            pst.execute();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
       Sale_Update_table();
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed

        snoS.setText("");
        dateS.setDate(null);
        SalCom.setSelectedItem(null);
        SaleManufactureTextfield.setText("");
        Sale_Quantity.setText("");
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed

        sno.setText("");
        Purdate.setDate(null);
        PurCom.setSelectedItem(null);
        PurchaseManufacture.setText("");
        purchase_Quantiy.setText("");
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed

        try{

            String sno1   = sno.getText();
            String date1  = (((JTextField)Purdate.getDateEditor().getUiComponent()).getText());
            String brand1   = PurCom.getSelectedItem().toString();
            String Manu = PurchaseManufacture.getText();
            String PurQ   = purchase_Quantiy.getText();

            String update = "update '"+PurCom.getSelectedItem()+"' set Id='"+sno1+"', PurDate='"+date1+"', PManufactureName='"+Manu+"', PBrandName='"+brand1+"', purchaseQuantity='"+PurQ+"' where id='"+sno1+"'";

            pst = conn.prepareStatement(update);
            pst.execute();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        finally{
            try{
                rs.close();
                pst.close();

            }
            catch(Exception e){}
        }
        Update_table();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        try{
            String sql = "insert into '"+PurCom.getSelectedItem()+"'(Purdate, PBrandName, PManufactureName, PurchaseQuantity) values(?,?,?,?)";
            pst = conn.prepareStatement(sql);

            //  pst.setString(1, sno.getText());
            pst.setString(1, ((JTextField) Purdate.getDateEditor().getUiComponent()).getText());
            pst.setString(2, PurCom.getSelectedItem().toString());
            pst.setString(3, PurchaseManufacture.getText());
            pst.setString(4, purchase_Quantiy.getText());

            pst.execute();

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
          Update_table();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void purchase_QuantiyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchase_QuantiyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purchase_QuantiyActionPerformed

    private void PurchaseManufactureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurchaseManufactureActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PurchaseManufactureActionPerformed

    private void PurComActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PurComActionPerformed

        try{

            String sql =" select * from  '"+PurCom.getSelectedItem()+"' ";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            purchaseTable.setModel(DbUtils.resultSetToTableModel(rs));
            InsertDataPurchase.setText("the record will save in "+PurCom.getSelectedItem().toString());

        }
        catch(Exception e){

            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){
            }
        }
    }//GEN-LAST:event_PurComActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed

        int p = JOptionPane.showConfirmDialog(null,"Do you Really want to Delete","Deleted",JOptionPane.YES_NO_OPTION );

        if(p == 0) {
            try{
                String sql="Delete from '"+jComboBox1.getSelectedItem()+"' where ID=?";

                pst= conn.prepareStatement(sql);
                pst.setString(1, sno.getText());

                pst.execute();

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
        try {
            Update_table();
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void SaleTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SaleTableMouseClicked
       
           try{
            int row = SaleTable.getSelectedRow();
            String table_clicked = (SaleTable.getModel().getValueAt(row, 0).toString());
            String sql = "select * from '"+jComboBox1.getSelectedItem()+"_sale"+"' where ID= '"+table_clicked+"' ";

            pst = conn.prepareStatement(sql);
            rs=pst.executeQuery();

            if(rs.next()){

                String add1 =rs.getString("ID");
                snoS.setText(add1);
                
                java.util.Date add22 = rs.getDate("SaleDate");
                dateS.setDate(add22);

                // combox should display
              //  String pur2 = rs.getString("SManufactureName");
                // PurCom.setText(pur2);
              //  PurCom.setSelectedItem(pur2);
                
                String add33 =rs.getString("SManufactureName");
                SaleManufactureTextfield.setText(add33);

                String add6 =rs.getString("SaleQuantity");
                Sale_Quantity.setText(add6);
                
                String pur2 = rs.getString("SBrandName");
                SalCom.setSelectedItem(pur2);
       }

     }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            //Update_table();
        }
         // Sale_Update_table();  
    }//GEN-LAST:event_SaleTableMouseClicked

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
      
          int p = JOptionPane.showConfirmDialog(null,"Do you Really want to Delete","Deleted",JOptionPane.YES_NO_OPTION );

        if(p == 0) {
            try{
                String sql="Delete from '"+jComboBox1.getSelectedItem()+"_sale"+"' where ID=?";

                pst= conn.prepareStatement(sql);
                pst.setString(1, snoS.getText());

                pst.execute();

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
        try {
            Sale_Update_table();
        }
        finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }

    }//GEN-LAST:event_jButton20ActionPerformed

    private void SaleTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SaleTableKeyReleased
        
         if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP){

            try{
                int row = SaleTable.getSelectedRow();
                String table_clicked = (SaleTable.getModel().getValueAt(row, 0).toString());
                String sql = "select * from '"+jComboBox1.getSelectedItem()+"_sale"+"' where ID= '"+table_clicked+"' ";

                pst = conn.prepareStatement(sql);
                rs=pst.executeQuery();

                if(rs.next()){

                    String add1 =rs.getString("ID");
                    snoS.setText(add1);
                    java.util.Date add2 = rs.getDate("SaleDate");
                    dateS.setDate(add2);
                    String add3 =rs.getString("SManufactureName");
                    SaleManufactureTextfield.setText(add3);
                    String add6 =rs.getString("SaleQuantity");
                    Sale_Quantity.setText(add6);
                    String add4 =rs.getString("SBrandName");
                    SalCom.setSelectedItem(add4);
                }

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);

            }
        }
    }//GEN-LAST:event_SaleTableKeyReleased

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        
        try{
            
        //    String selectedRows = recordT.getSelectedRow();
          recordT.print(JTable.PrintMode.NORMAL);
          
        }
        catch(java.awt.print.PrinterException e){
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void Purchase_ADD_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Purchase_ADD_BtnActionPerformed
        
        Double SubSale  = Double.parseDouble(purchase_Quantiy.getText());
        Double SubSale2 = Double.parseDouble(Purchase_Add_sub.getText());

        Double SaleSubOutput = SubSale + SubSale2;

        purchase_Quantiy.setText(String.valueOf(SaleSubOutput));
    }//GEN-LAST:event_Purchase_ADD_BtnActionPerformed

    private void Purchase_SUB_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Purchase_SUB_BtnActionPerformed
        
        Double SubSale  = Double.parseDouble(purchase_Quantiy.getText());
        Double SubSale2 = Double.parseDouble(Purchase_Add_sub.getText());

        Double SaleSubOutput = SubSale - SubSale2;

        purchase_Quantiy.setText(String.valueOf(SaleSubOutput));
    }//GEN-LAST:event_Purchase_SUB_BtnActionPerformed

    private void Sale_ADD_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sale_ADD_BtnActionPerformed
        
         Double SubSale  = Double.parseDouble(Sale_Quantity.getText());
         Double SubSale2 = Double.parseDouble(Sale_Add_sub.getText());

        Double SaleSubOutput = SubSale + SubSale2;

        Sale_Quantity.setText(String.valueOf(SaleSubOutput));
    }//GEN-LAST:event_Sale_ADD_BtnActionPerformed

    private void Sale_SUB_BtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sale_SUB_BtnActionPerformed
        
         Double SubSale  = Double.parseDouble(Sale_Quantity.getText());
         Double SubSale2 = Double.parseDouble(Sale_Add_sub.getText());

        Double SaleSubOutput = SubSale - SubSale2;

        Sale_Quantity.setText(String.valueOf(SaleSubOutput));
    }//GEN-LAST:event_Sale_SUB_BtnActionPerformed

    private void purchaseTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_purchaseTableKeyReleased
       
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP){

            try{
                int row = purchaseTable.getSelectedRow();
                String table_clicked = (purchaseTable.getModel().getValueAt(row, 0).toString());
                String sql = "select * from '"+jComboBox1.getSelectedItem()+"' where ID= '"+table_clicked+"' ";

                pst = conn.prepareStatement(sql);
                rs=pst.executeQuery();

                if(rs.next()){

                    String add1 =rs.getString("ID");
                    sno.setText(add1);

                    java.util.Date add2 = rs.getDate("PurDate");
                    Purdate.setDate(add2);

                    String add3 =rs.getString("PManufactureName");
                    PurchaseManufacture.setText(add3);

                    String add4 =rs.getString("PurchaseQuantity");
                    purchase_Quantiy.setText(add4);

                    String add5 =rs.getString("PBrandName");
                    PurCom.setSelectedItem(add5);

                   
                }

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);

            }
        }
    }//GEN-LAST:event_purchaseTableKeyReleased

    private void purchaseTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_purchaseTableMouseClicked
        
        try{
            int row = purchaseTable.getSelectedRow();
            String table_clicked = (purchaseTable.getModel().getValueAt(row, 0).toString());
            String sql = "select * from '"+jComboBox1.getSelectedItem()+"' where ID= '"+table_clicked+"' ";

            pst = conn.prepareStatement(sql);
            rs=pst.executeQuery();

            if(rs.next()){

                String add1 =rs.getString("ID");
                sno.setText(add1);

                /*  String add2 = rs.getDate("Date").toString();
                date_tf.setDateFormatString(add2);
                //  date_tf.setToolTipText(add2);     */
                /*   String add2 = rs.getString("Date");
                //    date_tf.setDateFormatString(add2);  */
                java.util.Date add2 = rs.getDate("PurDate");
                Purdate.setDate(add2);
                
                String add3 =rs.getString("PManufactureName");
                PurchaseManufacture.setText(add3);

                String add4 =rs.getString("PurchaseQuantity");
                purchase_Quantiy.setText(add4);

                String pur = rs.getString("PBrandName");
                PurCom.setSelectedItem(pur);
                

            }

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
           
        }
    }//GEN-LAST:event_purchaseTableMouseClicked

    private void searchSale_tf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchSale_tf1KeyReleased
      
        
             try{
            String sql = "Select * from '"+jComboBox1.getSelectedItem()+"_sale"+"' where ID=?";

            pst = conn.prepareStatement(sql);
            pst.setString(1, searchSale_tf1.getText());
            rs= pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("ID");
                snoS.setText(add1);
                java.util.Date add2 = rs.getDate("SaleDate");
                dateS.setDate(add2);
                String add4 = rs.getString("SManufactureName");
                SaleManufactureTextfield.setText(add4);
                String add5 = rs.getString("SaleQuantity");
                Sale_Quantity.setText(add5);
                String add3 = rs.getString("SBrandName");
                SalCom.setSelectedItem(add3);
          
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
             finally{
            try{
                rs.close();
                pst.close();
            }
            catch(Exception e){}
        }
             Sale_Update_table();
             
    }//GEN-LAST:event_searchSale_tf1KeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(viewTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewTable().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Date;
    private javax.swing.JMenu Date_txt;
    private javax.swing.JLabel InsertDataPurchase;
    private javax.swing.JLabel InsertDataSale;
    private javax.swing.JButton Print;
    private javax.swing.JComboBox PurCom;
    private javax.swing.JTextField PurchaseManufacture;
    private javax.swing.JButton Purchase_ADD_Btn;
    private javax.swing.JTextField Purchase_Add_sub;
    private javax.swing.JButton Purchase_SUB_Btn;
    private com.toedter.calendar.JDateChooser Purdate;
    private javax.swing.JComboBox SalCom;
    private javax.swing.JTextField SaleManufactureTextfield;
    private javax.swing.JTable SaleTable;
    private javax.swing.JButton Sale_ADD_Btn;
    private javax.swing.JTextField Sale_Add_sub;
    private javax.swing.JTextField Sale_Quantity;
    private javax.swing.JButton Sale_SUB_Btn;
    private javax.swing.JButton SaveReport;
    private javax.swing.JLabel ShowPurchaseName;
    private javax.swing.JLabel ShowSaleName;
    private javax.swing.JTextField T_Quantity;
    private javax.swing.JTextField T_pur;
    private javax.swing.JTextField T_sale;
    private javax.swing.JButton TotalQuantity;
    private com.toedter.calendar.JDateChooser dateS;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    public javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JTable purchaseTable;
    private javax.swing.JTextField purchase_Quantiy;
    private javax.swing.JTable recordT;
    private javax.swing.JTextField searchSale_tf1;
    private javax.swing.JTextField search_tf;
    private javax.swing.JTextField sno;
    private javax.swing.JTextField snoS;
    private javax.swing.JLabel time_txt;
    // End of variables declaration//GEN-END:variables
//String tname = null;
  //  http://9gag.com/gag/a1Xm7nD?ref=fbp
}
